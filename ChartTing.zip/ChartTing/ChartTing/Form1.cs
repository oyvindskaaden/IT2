﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChartTing
{
    public partial class karakterviser : Form
    {
        public karakterviser()
        {
            InitializeComponent();
        }

        #region Globale variabler

        string file = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Karakterer.csv" ;

        char delimiter = ',';

        List<Karakterer> Data = new List<Karakterer>();
        
        #endregion

        private void karakterviser_Load(object sender, EventArgs e)
        {

            using (StreamReader sr = new StreamReader(file))
            {
                while (!sr.EndOfStream)
                {

                    string read = sr.ReadLine();

                    var data = read.Split(delimiter);

                    int[] kar = new int[6];
                    for(int i = 1; i < data.Length; i++)
                    {
                        kar[i - 1] = Convert.ToInt32(data[i]);
                    }

                    Data.Add(new Karakterer(data[0], kar));
                }

            }
            //Console.WriteLine(Data[0].Karakter[1]);

            foreach (Karakterer k in Data)
            {
                chartKarakterer.Series.Add(k.Name);
                checkData.Items.Add(k.Name);
                for (int i = 0; i<k.Karakter.Length; i++)
                {
                    chartKarakterer.Series[k.Name].Points.AddXY(i, k.Karakter[i]);
                }
            }

        }

        private void ShowList(object sender, EventArgs e)
        {
            CheckBox c = sender as CheckBox;

            checkData.Visible = c.Checked;
        }

        private void ChangeData(object sender, EventArgs e)
        {
            for (int i = 0; i < checkData.Items.Count; i++)
            {
                //chartKarakterer.Series[i].Enabled = checkData.Items[i].Va;
            }
            
        }
    }
}
